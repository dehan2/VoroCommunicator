#pragma once
class VoroWebServer
{
public:
	VoroWebServer();
	~VoroWebServer();
};

